export default function Heatmap() {
  return (
    <div className="text-white p-6">
      Heatmap (teste)
    </div>
  );
}
