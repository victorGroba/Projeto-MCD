export default function DashboardOperacional() {
  return (
    <div className="text-white p-6">
      Dashboard Operacional (teste)
    </div>
  );
}
