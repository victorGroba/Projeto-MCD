export default function DashboardCliente() {
  return (
    <div className="text-white p-6">
      Dashboard Cliente (teste)
    </div>
  );
}
