export default function Graficos() {
  return (
    <div className="text-white p-6">
      Página de Gráficos (teste)
    </div>
  );
}
