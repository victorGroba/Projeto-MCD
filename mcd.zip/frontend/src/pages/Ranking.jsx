export default function Ranking() {
  return (
    <div className="text-white p-6">
      Ranking (teste)
    </div>
  );
}
